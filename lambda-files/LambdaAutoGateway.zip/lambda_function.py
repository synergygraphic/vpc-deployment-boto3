import boto3
import json
import logging
import os
from botocore.vendored import requests
from botocore.exceptions import ClientError
import time


EC2_CLIENT = boto3.client('ec2')
IAM_CLIENT = boto3.client('iam')

SUCCESS = "SUCCESS"
FAILED = "FAILED"

#FUNCION HANDLER PRINCIPAL
def lambda_handler(event, context):
    response_data = {}
    setup_logging()
    log.info('In Main Handler')
    log.info(json.dumps(event))
    print(json.dumps(event))
    
    account = os.environ['Account']
    region = os.environ['Region']
    vpc_id = os.environ['Vpc_Id']
    cidr = os.environ['CIDR']
    tgw_id = os.environ['Transit_Gateway_Id']

    if os.environ['RequestType'] in ['Update', 'Create']:
        log.info('Event = ' + os.environ['RequestType'])

        create_service_link_role()
        vpc_metadata = get_vpc_metadata(region, vpc_id, cidr)
        create_transit_gateways(vpc_metadata, tgw_id)
        create_vpc_route_to_tgw(vpc_metadata, tgw_id, cidr)

    else:
        log.error("failed to run")

    if os.environ['RequestType'] in ['Delete']:
        log.info('Event = ' + os.environ['RequestType'])


#FUNCION PARA CREAR LA RUTA EN EL ROUTE TABLE HACIA EL TGW 
def create_vpc_route_to_tgw(vpc_metadata, tgw_id, cidr):
    response_data = {}
    if vpc_metadata['Subnet']:
        try:
            describe_routes = EC2_CLIENT.describe_route_tables(
                RouteTableIds=[vpc_metadata['Route_Table']],
            )
            describe_routes = describe_routes['RouteTables']
            for route in describe_routes[0]['Routes']:
                if route['DestinationCidrBlock'] == cidr:
                    delete_existing_route = EC2_CLIENT.delete_route(
                        DestinationCidrBlock=cidr,
                        RouteTableId=vpc_metadata['Route_Table']
                    )
            create_route = EC2_CLIENT.create_route(
                RouteTableId=vpc_metadata['Route_Table'],
                DestinationCidrBlock=cidr,
                TransitGatewayId=tgw_id
            )
            
            log.info('CREATED ROUTE to ' + cidr + ' for  Routable '  +' with a destination of ' + tgw_id)

        except Exception as e:
            log.error(e)
            return None

#CREAR ATTACHMENT CON EL TGW Y EL VPC LOCAL
def create_transit_gateways(vpc_metadata, tgw_id):
    if len(vpc_metadata['Subnet']) > 0 :
        try:
            response = EC2_CLIENT.create_transit_gateway_vpc_attachment(
                TransitGatewayId=tgw_id,
                VpcId=vpc_metadata['Vpc'],
                SubnetIds=vpc_metadata['Subnet'],
            )
        except Exception as e:
            log.error(e)
            return None
    else:
        print('No subnets in VPC,' + entry['Vpc'] +' unable to attach VPC')
    time.sleep(90)
        


#ORGANIZA LA DATA Y LA AGRUPA EN UN DICCIONARIO PARA LUEGO SER PROCESADA
def get_vpc_metadata(region, vpc_id, cidr):
    metadata={}
    try:
        vpc_id = vpc_id
        subnets = get_subnets(vpc_id, region)
        route_table = get_default_route_table(vpc_id,cidr)
        metadata['Vpc'] = vpc_id
        metadata['Subnet'] = subnets
        metadata['Route_Table'] = route_table
    except Exception as e:
        log.error(e)
        return None
    return metadata


#MAPEA LAS SUBREDES ENLAS DIFERENTES ZONAS 
def get_subnets(vpc_id, region):
    a=[]
    b=[]
    c=[]
    mapping=[]
    subnet = []    
    subnet = EC2_CLIENT.describe_subnets(
        Filters=[       
            {
                'Name':'vpc-id',
                'Values': [vpc_id]
            },
            {
                'Name': 'tag:Type', 
                'Values': ['private']
            }
            
        ]
        )['Subnets']
    subnet_id=[]
    if len(subnet) > 0:
        subnet_id= [s['SubnetId'] for s in subnet]

    for i in subnet_id:
        response = EC2_CLIENT.describe_subnets(
            Filters=[
                {
                    'Name': 'subnet-id',
                    'Values': [i]
                },
            ],
        )['Subnets']
        
        for sub in response:
            if sub['AvailabilityZone'] == region+"a":
                if len(a)>0:
                    continue
                else:
                    a.append(sub['SubnetId'])
            elif sub['AvailabilityZone'] == region+"b":
                if len(b)>0:
                    continue
                else:
                    b.append(sub['SubnetId'])
            elif sub['AvailabilityZone'] == region+"c":
                if len(c)>0:
                    continue
                else:
                    c.append(sub['SubnetId'])
    mapping=a+b+c
    return mapping


#OBTIENE LA ROUTABLE PRIVADA PARA EL TRANSIT GATEWAY
def get_default_route_table(vpc_id,cidr):
    default_route_table = ''
    try:
        describe_route_tables = EC2_CLIENT.describe_route_tables(
            Filters=[
                {
                    'Name':'vpc-id',
                    'Values': [vpc_id]
                },
                {
                    'Name': 'tag:Type', 
                    'Values': ['private']
                }
            ]
        )
        default_route_table = describe_route_tables['RouteTables'][0]['RouteTableId']
        describe_routes = EC2_CLIENT.describe_route_tables(
            RouteTableIds=[
                default_route_table,
            ],
        )
        describe_routes = describe_routes['RouteTables']

        for route in describe_routes[0]['Routes']:
            if route['DestinationCidrBlock'] == cidr:

                delete_existing_route = EC2_CLIENT.delete_route(
                    DestinationCidrBlock=cidr,
                    RouteTableId=default_route_table
                )

    except Exception as e:
        log.error(e)
        return None
    return default_route_table

#CREA EL ROL PARA EL TRANSITGATEWAY
def create_service_link_role():
    service_role_exists = False

    list_roles = IAM_CLIENT.list_roles(
    )

    for role in list_roles['Roles']:
        if role['RoleName'] == 'AWSServiceRoleForVPCTransitGateway':
            service_role_exists = True


    if not service_role_exists:
        create_role = IAM_CLIENT.create_service_linked_role(
            AWSServiceName='transitgateway.amazonaws.com',
            )
        print(create_role)

    return()

#MANEJO ERRORES Y LOGS
def setup_logging():
    """Setup Logging."""
    global log
    log = logging.getLogger()
    log_levels = {'INFO': 20, 'WARNING': 30, 'ERROR': 40}

    if 'logging_level' in os.environ:
        log_level = os.environ['logging_level'].upper()
        if log_level in log_levels:
            log.setLevel(log_levels[log_level])
        else:
            log.setLevel(log_levels['ERROR'])
            log.error("The logging_level environment variable is not set \
                      to INFO, WARNING, or ERROR. \
                      The log level is set to ERROR")
    else:
        log.setLevel(log_levels['ERROR'])
        log.warning('The logging_level environment variable is not set.')
        log.warning('Setting the log level to ERROR')
    log.info('Logging setup complete - set to log level '
             + str(log.getEffectiveLevel()))
